from DataScienceTracker.Utils.dvc import set_dvc_remote, dvc_init, dvc_push, dvc_add, dvc_pull
from DataScienceTracker.Utils.git import git_init, config_git_user, config_remote, git_push, git_add, git_commit, git_tag, tag_exists
from DataScienceTracker.Utils.helpers import touch
import csv
import dvc
import json
import os
import pickle
import dvc.api

class DataTracking:
    """Data tracking class, contains information on the git and dvc repositories used for tracking data
    """
    def __init__(self, dir_path, dvc_remote_path, dvc_remote_name, git_remote_url, git_author_name, git_author_email):
        """DataTracking constructor.

        :param dir_path: absolute path to data versioning folder
        :type dir_path: str
        :param dvc_remote_path: absolute path to the remote storage for data versioning (check https://dvc.org/doc/command-reference/remote/add#supported-storage-types for supported storage types)
        :type dvc_remote_path: str
        :param dvc_remote_name: Name of the remote
        :type dvc_remote_name: str
        :param git_remote_url: Link to the git repository used to version data
        :type git_remote_url: str
        :param git_author_name: git user to be used. Will be configured locally
        :type git_author_name: str
        :param git_author_email: git email to be used. Will be configured locally
        :type git_author_email: str
        """
        self.dir_path = dir_path
        self.dvc_remote_path = dvc_remote_path
        self.dvc_remote_name = dvc_remote_name
        self.git_remote_url = git_remote_url
        self.git_author_name = git_author_name
        self.git_author_email = git_author_email
        self.data_version = ''

    def initialize_dvc_env(self):
        """Instantiate a Git and DVc repositories at the start of the project
        """
        git_init(self.dir_path)
        config_git_user(self.dir_path, self.git_author_name, self.git_author_email)
        config_remote(self.dir_path, self.git_remote_url)
        dvc_init(self.dir_path)
        set_dvc_remote(self.dir_path, self.dvc_remote_path, self.dvc_remote_name)
        git_push(self.dir_path)
        return

    def stage_file(self, file_path):
        """Creates tracking file for file_path and stages it in local git

        :param files_path: path to file to version
        :type files_path: str
        """
        # Add dvc tracking
        dvc_add(self.dir_path, file_path)

        # Track version on git
        git_add(self.dir_path, '*.gitignore')
        git_add(self.dir_path, f"{file_path}.dvc")
        return

    def store_staged_files(self, commit_message, tag, tag_message):
        """Pushes tracking files to git and tracked files to remote storage location

        :param commit_message: Commit message describing current version
        :type commit_message: str
        :param tag: data version
        :type tag: str
        :param tag_message: version description
        :type tag_message: str
        """
        git_commit(self.dir_path, commit_message)
        git_tag(self.dir_path, tag, tag_message)
        git_push(self.dir_path)
        dvc_push(self.dir_path, self.dvc_remote_name)
        return

    @staticmethod
    def gef_x_y_df_dict(x_train, x_test, y_train, y_test):
        """[summary]

        :param x_train: training values
        :type x_train: obj
        :param x_test: test values
        :type x_test: obj
        :param y_train: training labels
        :type y_train: obj
        :param y_test: test labels
        :type y_test: obj
        :return: dictionnary of type ``dict: { 'x_train' : x_train value}``
        :rtype: `dict` [`str`, `obj`]
        """
        return {"x_train": x_train, "x_test": x_test, "y_train":y_train, "y_test": y_test}

    @staticmethod
    def get_x_y_dict(version, file_format, project_prefix):
        """Creates a dictionnary containing the version of each dataset and the file path. Specific to the usecase of (x_train,x_test,y_train,y_test)

        :param version: data version ( common to the four files)
        :type version: str
        :param file_format: extansion of the files to be tracked ( csv, pkl, json ...)
        :type file_format: str
        :param project_prefix: project prefix to be appended to the version
        :type project_prefix: str
        :return: dictionnary of type ``dict: { 'tag' : str, 'path' : str }``
        :rtype: `dict` [`str`, `str`]
        """

        return DataTracking.get_dict(version, file_format, project_prefix, ["x_train", "x_test", "y_train", "y_test"])

    @staticmethod
    def get_dict(version, file_format, project_prefix, content):
        """Creates a dictionnary containing the version of each dataset and the file path.

        :param version: data version ( common to the four files)
        :type version: str
        :param file_format: extansion of the files to be tracked ( csv, pkl, json ...)
        :type file_format: str
        :param project_prefix: project prefix to be appended to the version
        :type project_prefix: str
        :param content: List of files used in the dict
        :type content: List[str]
        :return: dictionnary of type ``dict: { 'tag' : str, 'path' : str }``
        :rtype: `dict` [`str`, `str`]
        """
        var_dict = {}
        for var in content:
            path_var = f"{project_prefix}_{var}.{file_format}"

            var_dict[var] = {"tag": version, "path": path_var}

        return var_dict

    def dvc_tracking_train_test_xy(self, x_train, x_test, y_train, y_test, version, file_format="pkl", project_prefix=""):
        """Track datasets for experiments that require x_train, x_test, y_train, y_test

        :param x_train: training values
        :type x_train: obj
        :param x_test: test values
        :type x_test: obj
        :param y_train: training labels
        :type y_train: obj
        :param y_test: test labels
        :type y_test: obj
        :param version: tag version
        :type version: str
        :param file_format: file format to be used for storage, defaults to "pkl"
        :type file_format: str, optional
        :param project_prefix: prefix to be appendend to version, defaults to ""
        :type project_prefix: str, optional
        :return: dictionnary of type ``dict: { 'tag' : str, 'path' : str }``
        :rtype: `dict` [`str`, `str`]
        """

        x_y_df_dict = DataTracking.gef_x_y_df_dict(x_train, x_test, y_train, y_test)

        return self.dvc_tracking_train_test(x_y_df_dict, version, file_format, project_prefix)


    def dvc_tracking_train_test(self, df_dict, version, file_format="pkl", project_prefix=""):
        """Track datasets listed in df_dict

        :param df_dict: dictionnary of type ``dict: { 'dataset name' : dataset value}``
        :type df_dict: `dict` [`str`, `obj`]
        :param version: tag version
        :type version: str
        :param file_format: file format to be used for storage, defaults to "pkl"
        :type file_format: str, optional
        :param project_prefix: prefix to be appendend to version, defaults to ""
        :type project_prefix: str, optional
        :return: dictionnary of type ``dict: { 'tag' : str, 'path' : str }``
        :rtype: `dict` [`str`, `str`]
        """
        if tag_exists(self.dir_path, version):
            return print("Tag already exist, choose an other tag")

        var_dict = DataTracking.get_dict(version, file_format, project_prefix, list(df_dict.keys()))

        if file_format == "csv":
            for key, value in df_dict.items():
                value.to_csv(os.path.join(self.dir_path , var_dict[key]['path'], header=True, sep=";"))

        if file_format == "pkl":
            for key, value in df_dict.items():
                value.to_pickle(os.path.join(self.dir_path , var_dict[key]['path']))

        for key in var_dict.keys():
            self.stage_file(var_dict[key]["path"])

        self.store_staged_files(f"Add Train and test datasets for version: {version}", version, version)

        for key, value in df_dict.items():
            if os.path.isfile(os.path.join(self.dir_path, var_dict[key]['path'])):
                os.remove(os.path.join(self.dir_path ,  var_dict[key]['path']))

        self.data_version = version
        return var_dict

    def dvc_track_folder(self, folder_path, version, project_prefix=""):
        """track whole folder

        :param folder_path: path to folder to track
        :type folder_path: str
        :param version: tag version
        :type version: str
        :param project_prefix: prefix to be appendend to version, defaults to ""
        :type project_prefix: str, optional
        """

        self.stage_file(folder_path)

        self.store_staged_files(f"New verion for {folder_path}", version, version)
        self.data_version = version

    def dvc_track_file(self, file_path, version, project_prefix=""):
        """track specific file

        :param file_path: path to file to track
        :type file_path: str
        :param version: tag version
        :type version: str
        :param project_prefix: prefix to be appendend to version, defaults to ""
        :type project_prefix: str, optional
        """
        file_tag = f"{project_prefix}{file_path}"

        self.stage_file(file_tag)

        self.store_staged_files(f"Add new file {file_tag}", version, version)
        self.data_version = version

    def get_csv(self, file_path, version, delimiter=','):
        """Return the version `version` of a CSV file tracked by dvc

        :param file_path: name of the tracked file
        :type file_path: str
        :param version: version to retrieve
        :type version: str
        :param delimiter: delimiter for csv file, defaults to ','
        :type delimiter: str, optional
        :return: the retrieved dataset
        :rtype: obj
        """
        dataset = []
        with dvc.api.open(
                path=file_path,
                rev=version,
                remote=self.dvc_remote_name,
                repo=self.git_remote_url) as csvfile:
            read_csv = csv.reader(csvfile, delimiter=delimiter)

            for line in read_csv:
                dataset.append(line)
        return dataset

    def get_json(self, file_path, version):
        """Return the version `version` of a JSON file tracked by dvc

        :param file_path: name of the tracked file
        :type file_path: str
        :param version: version to retrieve
        :type version: str
        :return: the retrieved dataset
        :rtype: obj
        """
        dataset = []
        with dvc.api.open(
                path=file_path,
                rev=version,
                remote=self.dvc_remote_name,
                repo=self.git_remote_url) as fd:
            for line in fd:
                dataset.append(json.loads(line))
        return dataset

    def get_pickle(self, file_path, version):
        """Return the version `version` of a Pickle file tracked by dvc

        :param file_path: name of the tracked file
        :type file_path: str
        :param version: version to retrieve
        :type version: str
        :return: the retrieved dataset
        :rtype: obj
        """

        dvc_pull(self.dir_path, self.dvc_remote_name)
        dataset = pickle.loads(
            dvc.api.read(
                path=os.path.join(self.dir_path ,file_path),
                rev=version,
                remote=self.dvc_remote_name,
                repo=self.git_remote_url,
                mode='rb'
            )
        )
        return dataset


    def get_remote_train_test(self, train_test_dict, file_format="pkl", delimiter=";"):
        """Returns the values of the datasets in train_test_dictwith the correct version

        :param train_test_dict: dictionnary of type ``dict: { 'tag' : str, 'path' : str }``
        :type train_test_dict: `dict` [`str`, `str`]
        :param file_format: fileformat, defaults to "pkl"
        :type file_format: str, optional
        :param delimiter: delimiter used in case of csv file, defaults to ";"
        :type delimiter: str, optional
        :return: dictionnary of type ``dict: { 'dataset name' : dataset value}``
        :rtype: `dict` [`str`, `obj`]
        """
        dataset_dict = {}

        for key in train_test_dict.keys():

            if file_format == 'csv':
                data = self.get_csv(file_path=train_test_dict[key]["path"],
                                    version=train_test_dict[key]["tag"],
                                    delimiter=delimiter
                                    )

            if file_format == 'pkl':
                data = self.get_pickle(file_path=train_test_dict[key]["path"],
                                       version=train_test_dict[key]["tag"])

            dataset_dict[key] = data
        self.data_version = train_test_dict[key]["tag"]
        return dataset_dict

from sklearn.model_selection import GridSearchCV
import itertools
import mlflow
import mlflow.keras
import mlflow.sklearn
import numpy as np


class ModelTracking:
    """Model tracking class, contains information on the Mlflow server usedand has methods used to version models
    """
    def __init__(self, hostname, port, experiment, data_tracking=None, notebook_tracking=None):
        """Class constructor

        :param hostname: [url of the MLFLOW server
        :type hostname: str
        :param port: port used
        :type port: int
        :param experiment: Name of the experiment to run on MLflow
        :type experiment: str
        :param data_tracking: DataTracking instance, defaults to None
        :type data_tracking: DataTracking, optional
        :param notebook_tracking: NotebookTracking instance, defaults to None
        :type notebook_tracking: NotebookTracking, optional
        """
        self.hostname = hostname
        self.port = port
        self.experiment = experiment
        self.data_tracking = data_tracking
        self.notebook_tracking = notebook_tracking

    def init_mlflow(self):
        """Initiate connexion to MLFLOW
        """
        mlflow.set_tracking_uri(f"http://{self.hostname}:{self.port}")
        mlflow.set_experiment(self.experiment)

    @staticmethod
    def render_model_conf(model_name, pipe, parameters, metrics):
        """Create model configuration

        :param model_name: Name of the model to use
        :type model_name: str
        :param pipe: pipeline to be used
        :type pipe: sklearn.pipeline
        :param parameters: Lisr of parameter object
        :type parameters: list[dict['str', 'obj']]
        :param metrics: list of metrics
        :type metrics: list[(str, sklearn.metrics)]
        :return: dictionnary of type ``dict: { 'element' : element value}``
        :rtype: `dict` [`str`, `obj`]
        """
        model_conf_template = {"model_name": model_name, "pipe": pipe, "parameters": parameters, "metrics": metrics}
        return model_conf_template

    def cv_models_historisation(self, model_name, metrics, pipe, train_x, train_y, test_x, test_y, parameters, version):
        """Track model generated using cross validation on MLFLOW

        :param model_name: model name
        :type model_name: str
        :param metrics: list of metrics
        :type metrics: list[(str, sklearn.metrics)]
        :param pipe: pipeline to be used
        :type pipe: sklearn.pipeline
        :param x_train: training values
        :type x_train: obj
        :param x_test: test values
        :type x_test: obj
        :param y_train: training labels
        :type y_train: obj
        :param y_test: test labels
        :type y_test: obj
        :param parameters: Lisr of parameter object
        :type parameters: list[dict['str', 'obj']]
        """
        grid_search = GridSearchCV(pipe, param_grid=parameters, cv=3).fit(train_x, train_y)

        with mlflow.start_run(run_name=self.experiment):
            for param in grid_search.best_params_:
                mlflow.log_param(param, grid_search.best_params_[param])
            for metric_obj, metric_name in metrics:
                mlflow.log_metric(metric_name, metric_obj(grid_search.predict(test_x), test_y))
            mlflow.sklearn.log_model(grid_search, model_name)
            mlflow.log_param("model_name", model_name)
            mlflow.log_param("model_version", version)
            if self.data_tracking is not None:
                mlflow.log_param("git_repository", self.data_tracking.git_remote_url)
                mlflow.log_param("git_path", self.data_tracking.dir_path)
                mlflow.log_param("remote_storage_name", self.data_tracking.dvc_remote_name)
                mlflow.log_param("dataset_version", self.data_tracking.data_version)
            if self.notebook_tracking is not None:
                mlflow.log_param("notebook_dir", self.notebook_tracking.notebook_dir)
                mlflow.log_param("notebook_name", self.notebook_tracking.notebook_name)
                mlflow.log_param("notebook_version", self.notebook_tracking.notebook_version)
            mlflow.end_run()

    def models_historisation(self, model_name, metrics, pipe, train_x, train_y, test_x, test_y, parameters, mode):
        """Track model generated without cross validation on MLFLOW

        :param model_name: model name
        :type model_name: str
        :param metrics: list of metrics
        :type metrics: list[(str, sklearn.metrics)]
        :param pipe: pipeline to be used
        :type pipe: sklearn.pipeline
        :param x_train: training values
        :type x_train: obj
        :param x_test: test values
        :type x_test: obj
        :param y_train: training labels
        :type y_train: obj
        :param y_test: test labels
        :type y_test: obj
        :param parameters: Lisr of parameter object
        :type parameters: list[dict['str', 'obj']]
        :param mode: supervised or unsupervised
        :type mode: str
        """
        for step in parameters:
            for param_name in step:
                for value in step[param_name]:
                    pipe.set_params(**{param_name: value})
                    with mlflow.start_run(run_name=self.experiment):
                        for param in pipe.get_params():
                            if ("__" in param):
                                mlflow.log_param(param, pipe.get_params()[param])
                            for metric_obj, metric_name in metrics:
                                if mode == "supervised":
                                    fitted_model = pipe.fit(train_x, train_y)
                                    mlflow.log_metric(metric_name, metric_obj(fitted_model.predict(test_x), test_y))
                                elif mode == "unsupervised":
                                    mlflow.log_metric(metric_name, metric_obj(train_x, pipe.fit_predict(train_x)))
                        if self.data_tracking is not None:
                            mlflow.log_param("git_repository", self.data_tracking.git_remote_url)
                            mlflow.log_param("git_path", self.data_tracking.dir_path)
                            mlflow.log_param("remote_storage_name", self.data_tracking.dvc_remote_name)
                            mlflow.log_param("dataset_version", self.data_tracking.data_version)
                        if self.notebook_tracking is not None:
                            mlflow.log_param("notebook_dir", self.notebook_tracking.notebook_dir)
                            mlflow.log_param("notebook_name", self.notebook_tracking.notebook_name)
                            mlflow.log_param("notebook_version", self.notebook_tracking.notebook_version)
                        mlflow.sklearn.log_model("model_name", model_name)
                        mlflow.end_run()

    def stats_models_historisation(self,model, params, train, test, unsupervised):
        """Track time series models on MLFLOW

        :param model: dictionnary of type ``dict: { {model_name : {'class' : model_class, 'params': model_params}}}``
        :type model: list[dict]
        :param params: [description]
        :type params: str
        :param train: [description]
        :type train: str
        :param test: [description]
        :type test: str
        :param data_version: [description]
        :type data_version: str
        :param unsupervised: [description]
        :type unsupervised: str
        """
        keys, values = zip(*params.items())
        all_params = [dict(zip(keys, v)) for v in itertools.product(*values)]

        for dict_params in all_params:
            with mlflow.start_run(run_name=self.experiment):
                try:
                    mlflow.log_param('model', str(model))
                    for k, v in dict_params.items():
                        mlflow.log_param(k, v)
                    m = model(endog=train.squeeze(), **dict_params)
                    res = m.fit(disp=False)
                    if unsupervised:
                        mlflow.log_metric("aic", res.aic)
                    else:
                        true = test.squeeze().values
                        pred = res.forecast(len(true))
                        mlflow.log_metric("mse", ((true - pred) ** 2).mean())
                except (ValueError, np.linalg.LinAlgError, IndexError):
                    pass
                if self.data_tracking is not None:
                    mlflow.log_param("git_repository", self.data_tracking.git_remote_url)
                    mlflow.log_param("git_path", self.data_tracking.dir_path)
                    mlflow.log_param("remote_storage_name", self.data_tracking.dvc_remote_name)
                    mlflow.log_param("dataset_version", self.data_tracking.data_version)
                if self.notebook_tracking is not None:
                    mlflow.log_param("notebook_dir", self.notebook_tracking.notebook_dir)
                    mlflow.log_param("notebook_name", self.notebook_tracking.notebook_name)
                    mlflow.log_param("notebook_version", self.notebook_tracking.notebook_version)
                mlflow.end_run()

    def keras_model_historisation(self, model_name, metrics, keras_model, train_x, train_y, val_x, val_y, test_x, test_y, parameters, data_version):
        """Track keras models on MLFLOW

        :param model_name: [description]
        :type model_name: str
        :param metrics: [description]
        :type metrics: str
        :param keras_model: [description]
        :type keras_model: str
        :param train_x: [description]
        :type train_x: str
        :param train_y: [description]
        :type train_y: str
        :param val_x: [description]
        :type val_x: str
        :param val_y: [description]
        :type val_y: str
        :param test_x: [description]
        :type test_x: str
        :param test_y: [description]
        :type test_y: str
        :param parameters: [description]
        :type parameters: str
        :param data_version: [description]
        :type data_version: str
        """
        results = keras_model.fit(
            train_x, train_y, batch_size=parameters['batch_size'],
            epochs=parameters['epochs'], validation_data=(val_x, val_y), verbose=2)

        with mlflow.start_run(run_name=self.experiment):

            for param, param_value in parameters.items():
                mlflow.log_param(param, param_value)

            for metric_obj, metric_name in metrics:
                mlflow.log_metric(metric_name, metric_obj(keras_model.predict(test_x), test_y))

            mlflow.keras.log_model(keras_model, model_name)
            mlflow.log_param("model_name", model_name)
            if self.data_tracking is not None:
                mlflow.log_param("git_repository", self.data_tracking.git_remote_url)
                mlflow.log_param("git_path", self.data_tracking.dir_path)
                mlflow.log_param("remote_storage_name", self.data_tracking.dvc_remote_name)
                mlflow.log_param("dataset_version", data_version)
            if self.notebook_tracking is not None:
                mlflow.log_param("notebook_dir", self.notebook_tracking.notebook_dir)
                mlflow.log_param("notebook_name", self.notebook_tracking.notebook_name)
                mlflow.log_param("notebook_version", self.notebook_tracking.notebook_version)
            mlflow.end_run()

    def apply_models_with_cv(self, models, train_x, train_y, test_x, test_y, train_test_meta, version):
        """[summary]

        :param models: [description]
        :type models: str
        :param train_x: [description]
        :type train_x: str
        :param train_y: [description]
        :type train_y: str
        :param test_x: [description]
        :type test_x: str
        :param test_y: [description]
        :type test_y: str
        :param train_test_meta: [description]
        :type train_test_meta: str
        """

        if self.notebook_tracking is not None:
            self.notebook_tracking.version_notebook(version)
        else:
                        print(
                'The current notebook, which produced the result of this training, has not been tracked. If you want to track it, use the parameters, notebook, path, notebook_name and notebook_version')

        for model in models:
            self.cv_models_historisation(model['model_name'], model['metrics'], model['pipe'], train_x, train_y, test_x,
                                         test_y, model['parameters'], version)

    def apply_models_without_cv(self, models, train_x, train_test_meta, mode="unsupervised", train_y=None, test_x=None, test_y=None):
        """[summary]

        :param models: [description]
        :type models: str
        :param train_x: [description]
        :type train_x: str
        :param train_test_meta: [description]
        :type train_test_meta: str
        :param mode: [description], defaults to "unsupervised"
        :type mode: str, optional
        :param train_y: [description], defaults to None
        :type train_y: str, optional
        :param test_x: [description], defaults to None
        :type test_x: str, optional
        :param test_y: [description], defaults to None
        :type test_y: str, optional
        """
        data_version = "{train} | {test}".format(train=train_test_meta["train"]["tag"], test=train_test_meta["test"]["tag"])
        git_path = "{train} | {test}".format(train=train_test_meta["train"]["path"], test=train_test_meta["test"]["path"])


        for model in models:
            self.models_historisation(model['model_name'], model['metrics'], model['pipe'], train_x, train_y, test_x,
                                       test_y, model['parameters'], data_version, mode)
        if self.notebook_tracking is not None:
            self.notebook_tracking.version_notebook()

            print(
                'The current notebook, which produced the result of this training, has not been tracked. If you want to track it, use the parameters, notebook, path, notebook_name and notebook_version')


    def apply_stats_models(self, models, train, train_test_meta, test=None, unsupervised=True):
        """[summary]

        :param models: [description]
        :type models: str
        :param train: [description]
        :type train: str
        :param train_test_meta: [description]
        :type train_test_meta: str
        :param test: [description], defaults to None
        :type test: str, optional
        :param unsupervised: [description], defaults to True
        :type unsupervised: bool, optional
        """
        data_version = "{train} | {test}".format(train=train_test_meta["train"]["tag"], test=train_test_meta["test"]["tag"])
        git_path = "{train} | {test}".format(train=train_test_meta["train"]["path"], test=train_test_meta["test"]["path"])

        for key in models.keys():
            model = models[key]['class']
            params = models[key]['params']
            self.stats_models_historisation(model, params, train, test, data_version, unsupervised)

        if self.notebook_tracking is not None:
            self.notebook_tracking.version_notebook()

            print(
                'The current notebook, which produced the result of this training, has not been tracked. If you want to track it, use the parameters, notebook, path, notebook_name and notebook_version')

    def apply_model_keras(self, keras_model, train_x, train_y, val_x, val_y, test_x, test_y, train_test_meta):
        """[summary]

        :param keras_model: [description]
        :type keras_model: str
        :param train_x: [description]
        :type train_x: str
        :param train_y: [description]
        :type train_y: str
        :param val_x: [description]
        :type val_x: str
        :param val_y: [description]
        :type val_y: str
        :param test_x: [description]
        :type test_x: str
        :param test_y: [description]
        :type test_y: str
        :param train_test_meta: [description]
        :type train_test_meta: str
        """
        data_version = "{train}".format(train=train_test_meta["train"]["tag"])
        git_path = "{train}".format(train=train_test_meta["train"]["path"])

        self.keras_model_historisation(keras_model['model_name'], keras_model['metrics'], keras_model['pipe'], train_x, train_y,
                           val_x, val_y, test_x, test_y, keras_model['parameters'], data_version)
        if self.notebook_tracking is not None:
            self.notebook_tracking.version_notebook()

            print(
                'The current notebook, which produced the result of this training, has not been tracked. If you want to track it, use the parameters, notebook, path, notebook_name and notebook_version')

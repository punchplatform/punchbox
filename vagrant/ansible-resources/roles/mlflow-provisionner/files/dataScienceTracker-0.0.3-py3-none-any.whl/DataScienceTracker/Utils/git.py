import git
from git import Repo, TagReference
import logging
import os
from DataScienceTracker.Utils.helpers import touch


logger = logging.getLogger(__name__)
logger.setLevel(logging.WARNING)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(message)s')
stream_handler = logging.Handler()
stream_handler.setFormatter(formatter)


def is_git_dir(dir_path):
    """Checks if a repository is a git repository

    :param dir_path: Path to check
    :type dir_path: str
    :return: True if dir_path is a git repository, False if not
    :rtype: bool
    """
    try:
        _ = git.Repo(dir_path).git_dir
        return True
    except git.exc.InvalidGitRepositoryError:
        return False


def git_init(dir_path):
    """Instantiates dir_path as a git repo

    :param dir_path: Path to check
    :type dir_path: str
    :return: returns a newly created instance of the repo or the existent instance if already initialized
    :rtype: object
    """
    if is_git_dir(dir_path):
        logger.warning("File is already a git repository")
        return Repo(dir_path)

    Repo.init(dir_path)
    touch(os.path.join(dir_path, '.gitignore'))
    git_add(dir_path, '.gitignore')
    #git_commit(dir_path, 'Initial commit', check_staged=False)


def config_git_user(dir_path, name, email):
    """Configure git author to be used

    :param dir_path: Git repo path
    :type dir_path: str
    :param name: Name of the git author
    :type name: str
    :param email: email of the git author
    :type email: str
    """
    try:
        if not is_git_dir(dir_path):
            Repo.init(dir_path)

        repo = Repo(dir_path)
        repo.config_writer().set_value('user', 'name', name).release()
        repo.config_writer().set_value('user', 'email', email).release()
        return
    except Exception:
        logger.exception('Could not set author information')
        return


def config_remote(dir_path, remote_url, remote_name='origin'):
    """Configures the remote repo for our local git

    :param dir_path: Git repo path
    :type dir_path: str
    :param remote_url: Remote Git url
    :type remote_url: str
    :param remote_name: Remote branch name, defaults to 'origin'
    :type remote_name: str, optional

    """
    repo = Repo(dir_path)
    remotes = repo.remotes
    if remote_name in remotes:
        logger.exception('Remote exists')
        return
    else:
        repo.create_remote(remote_name, url=remote_url)
        return 


def git_add(dir_path, files):
    """Performs a git add in dir_path on the files in the array files

    :param dir_path: Git repo path
    :type dir_path: str
    :param files: List of files to add
    :type files: List[str]
    """
    repo = Repo(dir_path)
    repo.git.add(files)
    return


def git_commit(dir_path, commit_message, check_staged=True):
    """Performs a simple git commit on dir_path

    :param dir_path: Git repo path
    :type dir_path: str
    :param commit_message: Commit message
    :type commit_message: str
    :param check_staged: Activates a check to verify if there are staged files to commit, defaults to True
    :type check_staged: bool, optional
    """
    repo = Repo(dir_path)

    if check_staged is True:
        count_staged_files = len(repo.index.diff("HEAD"))
        if count_staged_files == 0:
            logger.warning("No staged files to commit")
            return
        else:
            repo.git.commit('-m', commit_message)
            return 
    else:
        repo.git.commit('-m', commit_message)
        return 


def git_tag(dir_path, tag, tag_message=''):
    """tags the repo in dir_path

    :param dir_path: Git repo path
    :type dir_path: str
    :param tag: tag version
    :type tag: str
    :param tag_message: tag description, defaults to ''
    :type tag_message: str, optional
    """
    repo = Repo(dir_path)
    repo.git.tag("-a", tag, "-m", tag_message)
    return 


def git_push(dir_path):
    """Push the changes to the remote

    :param dir_path: Git repo path
    :type dir_path: str
    """
    repo = Repo(dir_path)
    repo.git.push('--set-upstream', 'origin', 'master')
    repo.git.push('--tags')
    return


def git_checkout(dir_path, version):
    """Checkout the dvc file corresponding to the version

    :param dir_path: Git repo path
    :type dir_path: str
    :param version: tag version to checkout
    :type version: str
    """
    repo = Repo(dir_path)
    repo.git.checkout(version)
    return 


def get_git_logs(dir_path, dvc_file):
    """Retrieve commit history for dvc_file

    :param dir_path: Git repo path
    :type dir_path: str
    :param dvc_file: file for which we want the history
    :type dvc_file: str
    :return: file commit history object
    :rtype: object
    """
    repo = Repo(dir_path)
    return repo.git.log(dvc_file)


def tag_exists(dir_path, tag):
    """Check if tag is already present

    :param dir_path: Git repo path
    :type dir_path: str
    :param tag: tag version to look for
    :type tag: str
    :return: True if tag exists, false otherwise
    :rtype: bool
    """
    repo = Repo(dir_path)
    tagref = TagReference.list_items(repo)

    return tag in tagref

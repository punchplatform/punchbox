import subprocess
import os

def subprocess_cmd(command):
    """This function executes a bash command

    :param command: bash command to execute
    :type command: str
    :return: output, error pair returned by the command
    :rtype: (str,str)
    """
    process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
    output, error = process.communicate()
    return output, error


def touch(path):
    """This function simulates the touch bash command

    :param path: path to file to be created
    :type path: str
    """
    with open(path, 'a'):
        os.utime(path, None)

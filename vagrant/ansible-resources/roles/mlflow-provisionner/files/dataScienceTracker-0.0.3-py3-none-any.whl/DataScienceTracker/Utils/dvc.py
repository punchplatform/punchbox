from DataScienceTracker.Utils.git import git_add, git_commit, git_push, git_tag
from DataScienceTracker.Utils.helpers import subprocess_cmd
from os import path
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)s:%(message)s')
stream_handler = logging.Handler()
stream_handler.setFormatter(formatter)


def is_dvc_repo(dir_path):
    """Check if dvc is initiated in dir_path

    :param dir_path: Git repo path
    :type dir_path: str
    :return: True if repo is dvc initiated, False otherwise
    :rtype: bool
    """
    return path.exists(dir_path+"/.dvc")


def dvc_init(dir_path):
    """[summary]

    :param dir_path: Git repo path
    :type dir_path: str
    """
    if is_dvc_repo(dir_path):
        logger.exception("The current repo is already dvc initialised.")
        return
    dvc_dir = f"cd {dir_path}; dvc init;"
    _, err = subprocess_cmd(dvc_dir)
    if err is not None:
        logger.exception("DVC init failed")
        return
    git_commit(dir_path, "Initialize DVC project", check_staged=False)
    return


def set_dvc_remote(dir_path, remote_path, remote_name):
    """Defines the remote repo used to store the data

    :param dir_path: Git repo path
    :type dir_path: str
    :param remote_path: absolute path to the remote storage for data versioning (check https://dvc.org/doc/command-reference/remote/add#supported-storage-types for supported storage types)
    :type remote_path: str
    :param remote_name: Name of the remote 
    :type remote_name: str
    """
    _, err = subprocess_cmd(f'cd {dir_path}; dvc remote add -d {remote_name} {remote_path}')

    if err is not None:
        logger.exception("Could not set dvc remote")
        return
    else:
        git_add(dir_path, ['.dvc/config'])
        git_commit(dir_path, 'Remote dvc setup')
        return


def dvc_add(dir_path, data_dir):
    """Add changed data, results in updating the checksum in data.dvc file

    :param dir_path: Git repo path
    :type dir_path: str
    :param data_dir: data to be tracked ( could be file of folder)
    :type data_dir: str
    """
    _, err = subprocess_cmd(f'cd {dir_path}; dvc add {data_dir}')
    if err is not None:
        logger.exception("Could not add file to dvc")
        return
    else:
        logger.info(f"File {data_dir} added successfully")
        return


def dvc_pull(dir_path, remote_name):
    """Pull the data from the dvc remote repo

    :param dir_path: Git repo path
    :type dir_path: str
    :param remote_name: Name of the remote 
    :type remote_name: str
    """
    subprocess_cmd(f'cd {dir_path}; dvc pull --remote {remote_name}')
    return


def dvc_push(dir_path, remote_name):
    """Push the data to the dvc remote repo

    :param dir_path: Git repo path
    :type dir_path: str
    :param remote_name: Name of the remote 
    :type remote_name: str
    """
    subprocess_cmd(f'cd {dir_path}; dvc push --remote {remote_name}')
    return


def dvc_checkout(dir_path):
    """Checkout thedata referenced in the .dvc file

    :param dir_path: Git repo path
    :type dir_path: str
    """
    subprocess_cmd(f'cd {dir_path}; dvc checkout')
    return


def version_data(dir_path, data_dir,git_comment, tag, dvc_remote_name):
    """Push modified data

    :param dir_path: Git repo path
    :type dir_path: str
    :param data_dir: data to be tracked ( could be file of folder)
    :type data_dir: str
    :param git_comment: Commit message
    :type git_comment: str
    :param tag: version
    :type tag: str
    """
    dvc_add(dir_path, data_dir)
    git_add(dir_path, ['.gitignore', data_dir+'.dvc'])
    git_commit(dir_path, git_comment)
    git_tag(dir_path, tag)

    dvc_push(dir_path, dvc_remote_name)
    git_push(dir_path)
    return

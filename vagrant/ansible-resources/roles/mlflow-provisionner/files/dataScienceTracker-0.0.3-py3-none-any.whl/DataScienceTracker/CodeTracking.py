from DataScienceTracker.Utils.git import git_init, config_git_user, config_remote, git_add, git_commit, git_checkout, git_push, git_tag
import os


class CodeTracking:
    """Code tracking class, contains information on the git repository used for tracking code changes
    """
    def __init__(self, code_dir, git_remote_url, git_author_name, git_author_email):
        """Class constructor

        :param code_dir: Git repo containing the project
        :type code_dir: str
        :param git_remote_url: Link to the git repository used to version data
        :type git_remote_url: str
        :param git_author_name: git user to be used. Will be configured locally
        :type git_author_name: str
        :param git_author_email: git email to be used. Will be configured locally
        :type git_author_email: str
        """

        self.code_dir = code_dir
        self.git_remote_url = git_remote_url
        self.git_author_name = git_author_name
        self.git_author_email = git_author_email

        self.code_version = ''

    def initialize_code_env(self):
        """Instantiate a Git repository to track the code
        """
        git_init(self.code_dir)
        config_git_user(self.code_dir, self.git_author_name, self.git_author_email)
        config_remote(self.code_dir, self.git_remote_url)
        git_push(self.code_dir)
        return


    def code_tag(self,code_version):
        """create a tag containing the name and version of the code

        :param code_version: version
        :type code_version: str
        :return: tag 
        :rtype: str
        """
        self.code_version = code_version
        return code_version


    def version_code(self, code_version):
        """Versions and push the code to git

        :param code_version: version
        :type code_version: str
        """
        self.code_version = code_version
        git_add(self.code_dir, '--all')

        code_tag = self.code_tag(code_version)

        git_commit(self.code_dir, code_tag)

        # specify a tag to retrieve the version of the code
        git_tag(self.code_dir, code_tag)

        # push the commit to git
        git_push(self.code_dir)

    def get_code(self, code_version):
        """Checkout the `code_version` of the code

        :param code_version: version
        :type code_version: str
        """
        git_checkout(self.code_dir, self.code_tag(code_version))    
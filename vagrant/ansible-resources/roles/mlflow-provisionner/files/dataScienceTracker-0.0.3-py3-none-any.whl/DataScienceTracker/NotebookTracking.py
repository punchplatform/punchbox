from IPython.display import display, Javascript
from time import sleep
from DataScienceTracker.Utils.git import git_init, config_git_user, config_remote, git_add, git_commit, git_checkout, git_push, git_tag
import hashlib
import os


class NotebookTracking:
    """Notebook tracking class, contains information on the git repository used for tracking notebook changes
    """
    def __init__(self, notebook_dir, notebook_name, git_remote_url, git_author_name, git_author_email):
        """Class constructor

        :param notebook_dir: Git repo containing the notebook
        :type notebook_dir: str
        :param notebook_name: Name of the notebook to track
        :type notebook_name: str
        :param notebook_version: tag version
        :type notebook_version: str
        """

        self.notebook_dir = notebook_dir
        self.notebook_name = notebook_name
        self.git_remote_url = git_remote_url
        self.git_author_name = git_author_name
        self.git_author_email = git_author_email

        self.notebook_version = ''

    def initialize_notebook_env(self):
        """Instantiate a Git repository to track the notebook
        """
        git_init(self.notebook_dir)
        config_git_user(self.notebook_dir, self.git_author_name, self.git_author_email)
        config_remote(self.notebook_dir, self.git_remote_url)
        git_push(self.notebook_dir)
        return


    @property
    def notebook_file(self):
        """Adds ipynb extension to the file name

        :return: file name with notebook extension
        :rtype: str
        """
        return self.notebook_name + '.ipynb'

    @property
    def full_path(self):
        """Returns absolute path to the notebook

        :return: absolute path to the notebook
        :rtype: str
        """
        return os.path.join(self.notebook_dir, self.notebook_file)

    def notebook_tag(self,notebook_version):
        """create a tag containing the name and version of the notebook

        :param notebook_version: version
        :type notebook_version: str
        :return: tag 
        :rtype: str
        """
        self.notebook_version = notebook_version
        return self.notebook_name + '_' + notebook_version

    def save_notebook(self):
        """equivalent of clicking on File-> save on a jupyter notebook
        """
        start_md5 = hashlib.md5(open(self.full_path ,'rb').read()).hexdigest()
        display(Javascript('IPython.notebook.save_checkpoint();'))
        current_md5 = start_md5

        while start_md5 == current_md5:
            sleep(1)
            current_md5 = hashlib.md5(open(self.full_path, 'rb').read()).hexdigest()

    def version_notebook(self, notebook_version):
        """Versions and push the notebook to git

        :param notebook_version: version
        :type notebook_version: str
        """
        self.save_notebook()
        self.notebook_version = notebook_version
        git_add(self.notebook_dir, [self.notebook_file])

        notebook_tag = self.notebook_tag(notebook_version)

        git_commit(self.notebook_dir, notebook_tag)

        # specify a tag to retrieve the version of the notebook
        git_tag(self.notebook_dir, notebook_tag)

        # push the commit to git
        git_push(self.notebook_dir)

    def get_notebook(self, notebook_version):
        """Checkout the `notebook_version` of the notebook

        :param notebook_version: version
        :type notebook_version: str
        """
        git_checkout(self.notebook_dir, self.notebook_tag(notebook_version))